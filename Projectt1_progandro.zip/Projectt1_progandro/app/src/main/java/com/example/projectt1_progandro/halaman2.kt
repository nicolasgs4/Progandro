package com.example.projectt1_progandro

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class halaman2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.halaman2)

        val waktu = findViewById<RadioGroup>(R.id.waktu)
        val kelas = findViewById<RadioGroup>(R.id.kelas)

        val submit2 = findViewById<Button>(R.id.submit2)
        submit2.setOnClickListener {
            val kotaAsal = waktu.toString()
            val kotaTujuan = kelas.toString()


            val intent = Intent(this, halaman3::class.java)

            

            intent.putExtra("Ini Waktu keberangkatan Anda : ", kotaAsal)
            intent.putExtra("Ini Kelas Tiket Anda : ", kotaTujuan)

            startActivity(intent)
        }
    }
}