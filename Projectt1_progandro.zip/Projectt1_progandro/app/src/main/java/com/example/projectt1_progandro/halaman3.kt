package com.example.projectt1_progandro

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.w3c.dom.Text

class halaman3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.halaman3)

        val Asal = intent.getStringExtra("Asal Kota Anda Berangkat : ").toString()
        val Tujuan = intent.getStringExtra("Kota Tujuan Anda : ").toString()
        val Tanggal = intent.getStringExtra("Tanggal Keberangkatan Anda : ").toString()
        val Waktu = intent.getStringExtra("Waktu Keberangkatan Anda : ").toString()
        val Kelas = intent.getStringExtra("Kelas Tiket Anda : ").toString()

        val tampilan = findViewById<TextView>(R.id.tampilan)
        tampilan.text = "Kota Asal $Asal, Kota Tujuan $Tujuan, Waktu Keberangkatan $Waktu, Kelas Tiket $Kelas"
    }
}