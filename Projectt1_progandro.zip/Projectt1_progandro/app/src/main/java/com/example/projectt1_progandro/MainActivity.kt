package com.example.projectt1_progandro

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.DatePicker
import android.widget.EditText

import android.widget.RadioGroup


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val berangkat = findViewById<RadioGroup>(R.id.berangkat)
        val tujuan = findViewById<RadioGroup>(R.id.tujuan)
        val tanggalkeberangkatan = findViewById<EditText>(R.id.editTextDate)

        val submit1 = findViewById<Button>(R.id.submit1)
        submit1.setOnClickListener {
            val kotaAsal = berangkat.toString()
            val kotaTujuan = tujuan.toString()
            val tanggal = tanggalkeberangkatan.toString()


            val intent = Intent(this,halaman2::class.java)

            intent.putExtra("Ini Kota Asal Anda : ",kotaAsal)
            intent.putExtra("Ini Kota Tujuan Anda : ",kotaTujuan)
            intent.putExtra("Ini Tanggal Keberangkatan Anda : ",tanggal)
            startActivity(intent)
        }
    }
}